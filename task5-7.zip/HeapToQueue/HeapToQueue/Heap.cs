﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapToQueue
{
    public class Heap<T> where T : IComparable<T>
    {

        private readonly List<T> _items;

        public int Count { get { return _items.Count; } }
        public bool IsEmpty { get { return _items.Count == 0; } }
        public readonly bool IsMin;

        public T[] ToArray()
        {
            return _items.ToArray();   
        }






        public Heap(bool IsMin = false)
        {
            this.IsMin = IsMin;
            _items = new List<T>();
        }

        public Heap(T[] data, bool IsMin = false)
        {
            this.IsMin = IsMin;
            _items = new List<T>();
            if (data != null)
            {
                _items.AddRange(data);
                for (int i = (_items.Count - 1) / 2; i >= 0; i--)
                {
                    HeapDown(i);
                }
            }

            else
                Console.WriteLine("Ошибка: передан пустой массив!");
        }
        public bool IsMinOrMax(T a, T b)
        {
            int cmp = a.CompareTo(b);

            if (IsMin == true)
            {
                return cmp < 0; //значит куча min и меньший элемт должен быть выше
            }
            return cmp > 0;
        }
        public void Add(T item)
        {
            _items.Add(item);
            HeapUp(Count - 1);

        }

        private void HeapUp(int index)
        {
            while (index > 0)
            {
                int parent = (index - 1) / 2;
                if (!IsMinOrMax(_items[index], _items[parent]))
                {
                    break;
                }
                Swap(index, parent);
                index = parent;
            }
        }
        private void Swap(int i, int j)
        {
            T temp = _items[i];
            _items[i] = _items[j];
            _items[j] = temp;
        }
        public T Peek()
        {
            Console.WriteLine("Просмотр вершины");
            if (IsEmpty)
            {
                throw new InvalidOperationException("Куча пустая");
            }
            return _items[0];
        }
        public T Pop()
        {
            if (IsEmpty)
            {
                throw new InvalidOperationException("Куча пустая");
            }
            T root = _items[0];

            int lastIndex = _items.Count - 1;
            _items[0] = _items[lastIndex];
            _items.RemoveAt(lastIndex);

            if (!IsEmpty)
            {
                HeapDown(0);
            }
            return root;
        }

        private void HeapDown(int index)
        {
            int lastIndex = _items.Count - 1;
            while (true)
            {
                int leftReb = 2 * index + 1;
                int rightReb = 2 * index + 2;
                int maxi = index;


                if (leftReb <= lastIndex && IsMinOrMax(_items[leftReb], _items[maxi]))
                {
                    maxi = leftReb;
                }
                if (rightReb <= lastIndex && IsMinOrMax(_items[rightReb], _items[maxi]))
                {
                    maxi = rightReb;
                }

                if (maxi == index) { break; }

                Swap(index, maxi);
                index = maxi;

            }
        }

        public Heap<T> TwoHeapToOne(Heap<T> heap2)
        {
            if (this.IsEmpty) throw new InvalidOperationException("Куча1 пустая");
            if (heap2.IsEmpty) throw new InvalidOperationException("Куча2 пустая");
            if (this.IsMin != heap2.IsMin) throw new InvalidOperationException("Нельзя сливать разные типы куч.");
            Heap<T> result = new Heap<T>(this.IsMin);

            foreach (T item in _items)
            {

                result.Add(item);
            }

            foreach (T item in heap2._items)
            {
                result.Add(item);
            }
            return result;
        }
        public void UpdateKey(int index, T newValue)
        {
            if (index < 0 || index >= _items.Count)
                throw new ArgumentOutOfRangeException(nameof(index));

            T oldValue = _items[index];
            _items[index] = newValue;


            if (IsMinOrMax(newValue, oldValue)) HeapUp(index);
            else HeapDown(index);
        }

    }


}
