﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;



namespace HeapToQueue
{
    internal class Program
    {
        static void MAIN(string[] args)
        {
            Console.WriteLine("MIN-очередь:");

            var minPQ = new MyPriorityQueue<int>();   

            minPQ.Add(5);
            minPQ.Add(1);
            minPQ.Add(10);
            minPQ.Add(3);

            Console.WriteLine("Size: " + minPQ.Sizee());        
            Console.WriteLine("IsEmpty: " + minPQ.IsEmpty);       

            Console.WriteLine("peek(): " + minPQ.peek());         
            Console.WriteLine("element(): " + minPQ.Element()); 

            Console.WriteLine("Все элементы по возрастанию (poll):");
            while (!minPQ.IsEmpty)
            {
                Console.WriteLine(minPQ.Poll()); 
            }

            Console.WriteLine("IsEmpty после poll: " + minPQ.IsEmpty);

           
        }
    }
}
