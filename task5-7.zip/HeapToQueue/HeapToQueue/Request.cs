﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapToQueue
{
    public class RequestPriorityComparer : PriorityQueueComparer<Request>
    {
        public override int Compare(Request a, Request b)
        {
            int cmp = b._Priority.CompareTo(a._Priority);
            if (cmp != 0) return cmp;
            cmp = a._StepCreated.CompareTo(b._StepCreated);
            if (cmp != 0) return cmp;
            cmp = a._Numb.CompareTo(b._Numb);
            return cmp;
        }
    }
    public class Request : IComparable<Request>
    {
        public int _Priority { get; set; }
        public int _Numb { get; set; }
        public int _StepCreated { get; set; }
        public int _StepRemoved { get; set; }

        public int CompareTo(Request other)
        {
            if (other == null) return 1;
            return _Priority.CompareTo(other._Priority);
        }
    }
    class Program1
    {
        static void Main()
        {
            Console.WriteLine("Введите количество шагов генерации N: ");
            int n = int.Parse(Console.ReadLine());
            MyPriorityQueue<Request> queue = new MyPriorityQueue<Request>(11, new RequestPriorityComparer());
            Random rand = new Random();

            int currentStep = 0;
            int nextNumb = 1;

            int maxWait = -1;
            Request maxWaitRequest = null;
            using (var writer = new StreamWriter("C:\\Users\\M\\source\\repos\\HeapToQueue\\HeapToQueue\\log.txt", false, Encoding.UTF8))
            {
               
                for (int step = 1; step <= n; step++)
                {
                    currentStep = step;

                    
                    int countNew = rand.Next(1, 11); 
                    for (int i = 0; i < countNew; i++)
                    {
                        var req = new Request
                        {
                            _Numb = nextNumb++,
                            _Priority = rand.Next(1, 6),
                            _StepCreated = currentStep
                        };

                        queue.Add(req);
                        writer.WriteLine($"ADD {req._Numb} {req._Priority} {currentStep}");
                    }
                    RemoveOne(queue, currentStep, ref maxWait, ref maxWaitRequest, writer);
                }
                while (!queue.IsEmpty)
                {
                    currentStep++;
                    RemoveOne(queue, currentStep, ref maxWait, ref maxWaitRequest, writer);
                }

            }
            Console.WriteLine();
            if (maxWaitRequest != null)
            {
                Console.WriteLine("Заявка с максимальным временем ожидания:");
                Console.WriteLine($"Номер:           {maxWaitRequest._Numb}");
                Console.WriteLine($"Приоритет:       {maxWaitRequest._Priority}");
                Console.WriteLine($"Шаг поступления: {maxWaitRequest._StepCreated}");
                Console.WriteLine($"Шаг удаления:    {maxWaitRequest._StepRemoved}");
                Console.WriteLine($"Время ожидания:  {maxWaitRequest._StepRemoved - maxWaitRequest._StepCreated} шагов");
            }
            else
            {
                Console.WriteLine("Заявок не было.");
            }

           


        }

        private static void RemoveOne(MyPriorityQueue<Request> queue, int currentStep, ref int maxWait, ref Request maxWaitRequest, StreamWriter writer)
        {
            Request removed = queue.Poll();
            if (removed == null)
                return;

            removed._StepRemoved = currentStep;
            int wait = removed._StepRemoved - removed._StepCreated;

            if (wait > maxWait)
            {
                maxWait = wait;
                maxWaitRequest = removed;
            }

            writer.WriteLine($"REMOVE {removed._Numb} {removed._Priority} {currentStep}");
        }
    }
}
