﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HeapToQueue
{
    
    public abstract class PriorityQueueComparer<T>
    {
        public abstract int Compare(T a, T b);
    }
    public class MaxIntComparer : PriorityQueueComparer<int>
    {
        public override int Compare(int a, int b)
        {
            return a.CompareTo(b);
        }
    }
    public class MyPriorityQueue<T> where T : IComparable<T>
    {
        private T[] queue;
        private int size;
        private readonly PriorityQueueComparer<T> comparator;
        public int Size => size;
        public bool IsEmpty => size == 0;
        //1
        public MyPriorityQueue()
        {
            queue = new T[11];
            size = 0;
            comparator = null; 
        }

        //2
        public MyPriorityQueue(T[] a)
        {
            if (a == null) throw new InvalidOperationException("пусто");

            int cap = a.Length;
            queue = new T[cap];
            size = 0;
            comparator = null;

            foreach (T item in a)
            {
                Add(item);
            }
        }
        //3
        public MyPriorityQueue(int initialCapacity)
        {
            if (initialCapacity <= 0)
                throw new InvalidOperationException("пусто");

            queue = new T[initialCapacity];
            size = 0;
            comparator = null;
        }

        //4
        public MyPriorityQueue(int initialCapacity, PriorityQueueComparer<T> comparator)
        {
            if (initialCapacity <= 0)
                throw new InvalidOperationException("нельзя");

            queue = new T[initialCapacity];
            size = 0;
            this.comparator = comparator;
        }

        //5
        public MyPriorityQueue(MyPriorityQueue<T> c)
        {
            if (c == null) throw new InvalidOperationException("пусто");

            // копируем массив и размер
            queue = new T[c.queue.Length];
            Array.Copy(c.queue, queue, c.size);
            size = c.size;
            comparator = c.comparator;
        }

        private int Compare(T a, T b)
        {
            if (comparator != null)
                return comparator.Compare(a, b);

            // естественный порядок
            return a.CompareTo(b);
        }

        private bool HigherPriority(T a, T b)
        {
            // для min-очереди: a "важнее", если a < b
            return Compare(a, b) < 0;
        }



        private void CapacityForAdd6()
        {
            if (size < queue.Length) return;

            int oldCap = queue.Length;
            int newCap;

            if (oldCap < 64)
                newCap = oldCap * 2;
            else
                newCap = oldCap + oldCap / 2; // +50%

            T[] newArr = new T[newCap];
            Array.Copy(queue, newArr, size);
            queue = newArr;
        }



        private void SiftUp(int index)
        {
            while (index > 0)
            {
                int parent = (index - 1) / 2;
                if (!HigherPriority(queue[index], queue[parent]))
                    break;

                Swap(index, parent);
                index = parent;
            }
        }

        private void SiftDown(int index)
        {
            while (true)
            {
                int left = 2 * index + 1;
                int right = 2 * index + 2;
                int best = index;

                if (left < size && HigherPriority(queue[left], queue[best]))
                    best = left;

                if (right < size && HigherPriority(queue[right], queue[best]))
                    best = right;

                if (best == index)
                    break;

                Swap(index, best);
                index = best;
            }
        }

        private void Swap(int i, int j)
        {
            T tmp = queue[i];
            queue[i] = queue[j];
            queue[j] = tmp;
        }

      
        //6
        public void Add(T e)
        {
            CapacityForAdd6();
            queue[size] = e;
            SiftUp(size);
            size++;
        }
        //7
        public void AddAll(T[] array)
        {
            if (array == null) throw new InvalidOperationException("пусто");
            foreach (T e in array)
            {
              Add(e);
            }
        }
        //8
        public void Clear()
        {
            queue = new T[queue.Length];
            size = 0;

        }
        //9
        public bool Contains(object o)
        {
            if (o == null)
                return false;


            for (int i = 0; i < size; i++)
            {
                if (Equals(queue[i], o))
                    return true;
            }

            return false;
        }
        //10
        public bool ContainsAll(T[] arr)
        {
            if (arr == null)
                return false;

            for (int i = 0; i < arr.Length; i++)
            {
                bool found = false;

                for (int j = 0; j < size; j++)
                {
                    if (Equals(queue[j], arr[i]))
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                    return false; 
            }

            return true; 
        }

        //11
        public bool ISEmpty()
        {
            if(size==0) return true; 
            else return false ;
        }
        //12
        public bool Remove(object o)
        {
            for (int i = 0; i < size; i++)
            {
                if (Equals(queue[i], o))
                {
                   
                    size--;
                    queue[i] = queue[size];
                    queue[size] = default; 

                    
                    SiftDown(i);
                    SiftUp(i);

                    return true;
                }
            }
            return false;
        }
        //13
        public void RemoveAll(T[] a)
        {
            if (a == null)
                return;

            for (int i = 0; i < a.Length; i++)
            {
                while (Remove(a[i])) { }
            }
        }
        //14
        public void RetainAll(T[] a)
        {
            if (a == null)
                return;

            int i = 0;
            while (i < size)
            {
                if (!Contains(queue[i]))
                {
                    size--;
                    queue[i] = queue[size];
                    queue[size] = default;
                    SiftDown(i);
                    SiftUp(i);
                }
                else
                {
                    i++;
                }
            }
        }
        //15
        public int Sizee()
        {
            return size;
        }
        //16
        public T[] ToArray()
        {
            T[] result = new T[size];
            Array.Copy(queue, 0, result, 0, size);
            return result;
        }
        //17
        public T[] ToArray(T[] a)
        {
            if (a == null)
            {
                T[] result = new T[size];
                Array.Copy(queue, 0, result, 0, size);
                return result;
            }
            if (a.Length < size)
            {
                T[] result = new T[size];
                Array.Copy(queue, 0, result, 0, size);
                return result;
            }

         
            Array.Copy(queue, 0, a, 0, size);

            return a;
        }
        //18
        public T Element()
        {
            if (size == 0)
                throw new InvalidOperationException("Очередь пуста");

            return queue[0];
        }
        //19
        public bool Offer(T obj)
        {
            Add(obj);
            return true;
        }
        //20
        public T peek()
        {
            if (size == 0)
                return default;
            return queue[0];    
        }
        //21
        public T Poll()
        {
            if (size == 0)  return default;
            T a = queue[0];
            Remove(queue[0]);
            return a;
        }

    }
}
