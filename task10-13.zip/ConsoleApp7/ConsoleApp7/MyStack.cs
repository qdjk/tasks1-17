﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{

    public class MyStack<T> : MyVector<T>
        {
            public MyStack() : base()
            {
            }

            public MyStack(int initialCapacity) : base(initialCapacity)
            {
            }

            public MyStack(T[] a) : base(a)
            {
            }


            public void Push(T item)
            {
                Add(item);
            }


            public T Pop()
            {
                if (IsEmpty())
                    throw new InvalidOperationException("пусто");

                int lastIndex = Size() - 1;
                T value = Get(lastIndex);
                Remove(lastIndex);
                return value;
            }


            public T Peek()
            {
                if (IsEmpty())
                    throw new InvalidOperationException("пусто");

                return Get(Size() - 1);
            }


            public bool Empty()
            {
                return IsEmpty();
            }


            public int Search(T item)
            {
                int size = Size();
                int pos = 1; // позиция от вершины

                for (int i = size - 1; i >= 0; i--)
                {
                    T value = Get(i);
                    if (object.Equals(value, item))
                        return pos;

                    pos++;
                }

                return -1;
            }
        }
    class Program1
    {

        static void MAIN()
        {
            MyStack<int> stack = new MyStack<int>();

            stack.Push(10);
            stack.Push(20);
            stack.Push(30);
            Console.WriteLine("После push 3 раза size = "+stack.Size());

            Console.WriteLine("Пустой? " + stack.Empty());
            Console.WriteLine("Верхний элемент (Peek): " + stack.Peek());

            Console.WriteLine("30 Индекс " + stack.Search(30));
            Console.WriteLine("20 Индекс " + stack.Search(20)); 
            Console.WriteLine("10 Индекс  " + stack.Search(10)); 
            Console.WriteLine("99 Индекс  " + stack.Search(99));

            int x = stack.Pop();
            Console.WriteLine("Pop() вернул: " + x);
            x = stack.Pop();
            Console.WriteLine("Pop() вернул: " + x);
            x = stack.Pop();
            Console.WriteLine("Pop() вернул: " + x);
            Console.WriteLine("Пустой? " + stack.Empty());



            Console.ReadLine();
        }

    }

}
