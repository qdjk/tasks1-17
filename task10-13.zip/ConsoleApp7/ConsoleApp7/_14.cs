﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp7
{
    class Program14
    {
        static bool IsLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        }

        static bool IsDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

        static bool IsOperatorToken(string token)
        {
            if (token == "+" || token == "-" || token == "*" || token == "/" || token == "^")
                return true;
            if (token == "mod" || token == "div")
                return true;
            return false;
        }

        static bool IsFunctionToken(string token)
        {
            if (token == "sqrt" || token == "abs" || token == "sign" ||
                token == "sin" || token == "cos" || token == "tan" ||
                token == "ln" || token == "log" || token == "exp" ||
                token == "trunc" || token == "min" || token == "max")
                return true;
            return false;
        }

        static int GetPrecedence(string op)
        {
            if (op == "+" || op == "-")
                return 1;
            if (op == "*" || op == "/" || op == "mod" || op == "div")
                return 2;
            if (op == "^")
                return 3;
            return 0;
        }

        static bool IsRightAssociative(string op)
        {
            return op == "^";
        }

        static bool IsNumberToken(string token)
        {
            if (string.IsNullOrEmpty(token))
                return false;

            int i = 0;
            if (token[0] == '+' || token[0] == '-')
            {
                if (token.Length == 1)
                    return false;
                i = 1;
            }

            bool hasDot = false;

            for (; i < token.Length; i++)
            {
                char c = token[i];
                if (IsDigit(c))
                    continue;
                if (c == '.' && !hasDot)
                {
                    hasDot = true;
                    continue;
                }
                return false;
            }

            return true;
        }

        static double ApplyOperator(string op, double a, double b)
        {
            if (op == "+") return a + b;
            if (op == "-") return a - b;
            if (op == "*") return a * b;
            if (op == "/")
            {
                if (b == 0.0) throw new DivideByZeroException("Деление на ноль");
                return a / b;
            }
            if (op == "^") return Math.Pow(a, b);
            if (op == "mod")
            {
                if (b == 0.0) throw new DivideByZeroException("Деление на ноль в mod");
                return a % b;
            }
            if (op == "div")
            {
                if (b == 0.0) throw new DivideByZeroException("Деление на ноль в div");
                double q = a / b;
                return Math.Truncate(q);
            }

            throw new Exception("Неизвестный оператор: " + op);
        }

        static double ApplyFunction1(string func, double x)
        {
            if (func == "sqrt")
            {
                if (x < 0.0) throw new Exception("Квадратный корень из отрицательного числа");
                return Math.Sqrt(x);
            }
            if (func == "abs") return Math.Abs(x);
            if (func == "sign") return Math.Sign(x);
            if (func == "sin") return Math.Sin(x);
            if (func == "cos") return Math.Cos(x);
            if (func == "tan") return Math.Tan(x);
            if (func == "ln")
            {
                if (x <= 0.0) throw new Exception("Логарифм от неположительного числа");
                return Math.Log(x);
            }
            if (func == "log")
            {
                if (x <= 0.0) throw new Exception("Логарифм от неположительного числа");
                return Math.Log10(x);
            }
            if (func == "exp") return Math.Exp(x);
            if (func == "trunc") return Math.Truncate(x);

            throw new Exception("Неизвестная функция: " + func);
        }

        static double ApplyFunction2(string func, double a, double b)
        {
            if (func == "min") return a < b ? a : b;
            if (func == "max") return a > b ? a : b;
            throw new Exception("Неизвестная двухаргументная функция: " + func);
        }

        static string[] ToRpn(string expr)
        {
            MyStack<string> opStack = new MyStack<string>();
            MyVector<string> output = new MyVector<string>();

            int i = 0;
            while (i < expr.Length)
            {
                char c = expr[i];

                if (c == ' ' || c == '\t')
                {
                    i++;
                    continue;
                }

                if (IsDigit(c) || c == '.')
                {
                    int start = i;
                    bool hasDot = false;

                    while (i < expr.Length)
                    {
                        char ch = expr[i];
                        if (IsDigit(ch))
                        {
                            i++;
                        }
                        else if (ch == '.' && !hasDot)
                        {
                            hasDot = true;
                            i++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    string number = expr.Substring(start, i - start);
                    output.Add(number);
                    continue;
                }

                if (IsLetter(c))
                {
                    int start = i;
                    while (i < expr.Length && IsLetter(expr[i]))
                        i++;

                    string name = expr.Substring(start, i - start);

                    if (IsOperatorToken(name))
                    {
                        while (!opStack.Empty() && IsOperatorToken(opStack.Peek()) &&
                               ((IsRightAssociative(name) == false && GetPrecedence(name) <= GetPrecedence(opStack.Peek())) ||
                                (IsRightAssociative(name) == true && GetPrecedence(name) < GetPrecedence(opStack.Peek()))))
                        {
                            output.Add(opStack.Pop());
                        }

                        opStack.Push(name);
                    }
                    else if (IsFunctionToken(name))
                    {
                        opStack.Push(name);
                    }
                    else
                    {
                        output.Add(name);
                    }

                    continue;
                }

                if (c == '(')
                {
                    opStack.Push("(");
                    i++;
                    continue;
                }

                if (c == ')')
                {
                    bool foundLeft = false;
                    while (!opStack.Empty())
                    {
                        string op = opStack.Pop();
                        if (op == "(")
                        {
                            foundLeft = true;
                            break;
                        }
                        else
                        {
                            output.Add(op);
                        }
                    }

                    if (!foundLeft)
                        throw new Exception("Нет открывающей скобки");

                    if (!opStack.Empty() && IsFunctionToken(opStack.Peek()))
                    {
                        output.Add(opStack.Pop());
                    }

                    i++;
                    continue;
                }

                if (c == ',' || c == ';')
                {
                    bool foundLeft = false;
                    while (!opStack.Empty() && opStack.Peek() != "(")
                    {
                        output.Add(opStack.Pop());
                    }
                    if (opStack.Empty())
                        throw new Exception("Неверный разделитель аргументов");
                    i++;
                    continue;
                }

                if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^')
                {
                    string op1 = c.ToString();
                    i++;

                    while (!opStack.Empty() && IsOperatorToken(opStack.Peek()) &&
                           ((IsRightAssociative(op1) == false && GetPrecedence(op1) <= GetPrecedence(opStack.Peek())) ||
                            (IsRightAssociative(op1) == true && GetPrecedence(op1) < GetPrecedence(opStack.Peek()))))
                    {
                        output.Add(opStack.Pop());
                    }

                    opStack.Push(op1);
                    continue;
                }

                throw new Exception("Неизвестный символ: " + c);
            }

            while (!opStack.Empty())
            {
                string op = opStack.Pop();
                if (op == "(" || op == ")")
                    throw new Exception("Несоответствие скобок");
                output.Add(op);
            }

            return output.ToArray();
        }

        static void CollectVariables(string[] tokens, MyVector<string> varNames)
        {
            for (int i = 0; i < tokens.Length; i++)
            {
                string token = tokens[i];
                if (string.IsNullOrEmpty(token))
                    continue;

                if (IsNumberToken(token))
                    continue;
                if (IsOperatorToken(token))
                    continue;
                if (IsFunctionToken(token))
                    continue;

                if (varNames.IndexOf(token) == -1)
                    varNames.Add(token);
            }
        }

        static MyVector<double> ReadVariableValues(MyVector<string> varNames)
        {
            MyVector<double> values = new MyVector<double>();

            for (int i = 0; i < varNames.Size(); i++)
            {
                string name = varNames.Get(i);
                Console.Write("Введите значение для " + name + ": ");
                string s = Console.ReadLine();
                double v;

                try
                {
                    v = double.Parse(s, CultureInfo.InvariantCulture);
                }
                catch
                {
                    throw new Exception("Невозможно прочитать число для переменной " + name);
                }

                values.Add(v);
            }

            return values;
        }

        static double EvaluateRpn(string[] tokens, MyVector<string> varNames, MyVector<double> varValues)
        {
            MyStack<double> stack = new MyStack<double>();

            for (int i = 0; i < tokens.Length; i++)
            {
                string token = tokens[i];
                if (string.IsNullOrEmpty(token))
                    continue;

                if (IsNumberToken(token))
                {
                    double value = double.Parse(token, CultureInfo.InvariantCulture);
                    stack.Push(value);
                }
                else if (IsOperatorToken(token))
                {
                    if (stack.Size() < 2)
                        throw new Exception("Мало операндов для оператора " + token);

                    double b = stack.Pop();
                    double a = stack.Pop();
                    double res = ApplyOperator(token, a, b);
                    stack.Push(res);
                }
                else if (IsFunctionToken(token))
                {
                    if (token == "min" || token == "max")
                    {
                        if (stack.Size() < 2)
                            throw new Exception("Мало операндов для функции " + token);

                        double b = stack.Pop();
                        double a = stack.Pop();
                        double res = ApplyFunction2(token, a, b);
                        stack.Push(res);
                    }
                    else
                    {
                        if (stack.Size() < 1)
                            throw new Exception("Мало операндов для функции " + token);

                        double x = stack.Pop();
                        double res = ApplyFunction1(token, x);
                        stack.Push(res);
                    }
                }
                else
                {
                    int index = varNames.IndexOf(token);
                    if (index == -1)
                        throw new Exception("Неизвестная переменная: " + token);

                    double value = varValues.Get(index);
                    stack.Push(value);
                }
            }

            if (stack.Size() != 1)
                throw new Exception("Неверное выражение");

            return stack.Pop();
        }

        static void Main(string[] args)
        {
            string expr;

            if (args != null && args.Length > 0)
            {
                expr = string.Join(" ", args);
            }
            else
            {
                Console.WriteLine("Введите выражение:");
                expr = Console.ReadLine();
            }

            try
            {
                string[] rpn = ToRpn(expr);

                MyVector<string> varNames = new MyVector<string>();
                CollectVariables(rpn, varNames);

                MyVector<double> varValues = ReadVariableValues(varNames);

                double result = EvaluateRpn(rpn, varNames, varValues);

                Console.WriteLine("Результат: " + result.ToString(CultureInfo.InvariantCulture));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        }
    }
}
    
