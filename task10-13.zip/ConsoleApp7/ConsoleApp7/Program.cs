﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace ConsoleApp7
{
    public class MyVector<T>
    {
        private T[] elementData;
        private int elementCount;
        private int capacityIncrement;

        public MyVector(int initialCapacity, int capacityIncrement)
        {
            if (initialCapacity < 0)
                throw new ArgumentOutOfRangeException("initialCapacity");
            if (capacityIncrement < 0)
                throw new ArgumentOutOfRangeException("capacityIncrement");

            elementData = new T[initialCapacity];
            elementCount = 0;
            this.capacityIncrement = capacityIncrement;
        }

        public MyVector(int initialCapacity)
            : this(initialCapacity, 0)
        {
        }

        public MyVector()
            : this(10, 0)
        {
        }

        public MyVector(T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");

            elementData = new T[a.Length];
            for (int i = 0; i < a.Length; i++)
                elementData[i] = a[i];

            elementCount = a.Length;
            capacityIncrement = 0;
        }


        private void EnsureCapacity(int minCapacity)
        {
            if (elementData.Length >= minCapacity)
                return;

            int newCapacity;
            if (elementData.Length == 0)
                newCapacity = 1;
            else if (capacityIncrement > 0)
                newCapacity = elementData.Length + capacityIncrement;
            else
                newCapacity = elementData.Length * 2;

            if (newCapacity < minCapacity)
                newCapacity = minCapacity;

            T[] newArray = new T[newCapacity];
            for (int i = 0; i < elementCount; i++)
                newArray[i] = elementData[i];

            elementData = newArray;
        }

        // 5
        public void Add(T e)
        {
            EnsureCapacity(elementCount + 1);
            elementData[elementCount] = e;
            elementCount++;
        }

        // 6
        public void AddAll(T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");

            if (a.Length == 0)
                return;

            EnsureCapacity(elementCount + a.Length);
            for (int i = 0; i < a.Length; i++)
            {
                elementData[elementCount] = a[i];
                elementCount++;
            }
        }

        // 7
        public void Clear()
        {
            for (int i = 0; i < elementCount; i++)
                elementData[i] = default(T);

            elementCount = 0;
        }

        // 8
        public bool Contains(object o)
        {
            return IndexOf(o) != -1;
        }

        // 9
        public bool ContainsAll(T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");

            for (int i = 0; i < a.Length; i++)
            {
                if (!Contains(a[i]))
                    return false;
            }
            return true;
        }

        // 10
        public bool IsEmpty()
        {
            return elementCount == 0;
        }

        // 11
        public bool Remove(object o)
        {
            int index = IndexOf(o);
            if (index == -1)
                return false;

            Remove(index);
            return true;
        }

        // 12
        public bool RemoveAll(T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");

            bool changed = false;

            for (int i = 0; i < a.Length; i++)
            {
                object value = a[i];
                bool removedOne = true;
                while (removedOne)
                {
                    int index = IndexOf(value);
                    if (index == -1)
                    {
                        removedOne = false;
                    }
                    else
                    {
                        Remove(index);
                        changed = true;
                    }
                }
            }

            return changed;
        }

        // 13
        public bool RetainAll(T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");

            int newSize = 0;

            for (int i = 0; i < elementCount; i++)
            {
                T value = elementData[i];
                bool keep = false;

                for (int j = 0; j < a.Length; j++)
                {
                    if (object.Equals(value, a[j]))
                    {
                        keep = true;
                        break;
                    }
                }

                if (keep)
                {
                    elementData[newSize] = value;
                    newSize++;
                }
            }

            for (int i = newSize; i < elementCount; i++)
                elementData[i] = default(T);

            bool changed = newSize != elementCount;
            elementCount = newSize;

            return changed;
        }

        // 14
        public int Size()
        {
            return elementCount;
        }

        // 15
        public T[] ToArray()
        {
            T[] result = new T[elementCount];
            for (int i = 0; i < elementCount; i++)
                result[i] = elementData[i];
            return result;
        }

        // 16
        public T[] ToArray(T[] a)
        {
            if (a == null || a.Length < elementCount)
            {
                T[] result = new T[elementCount];
                for (int i = 0; i < elementCount; i++)
                    result[i] = elementData[i];
                return result;
            }
            else
            {
                for (int i = 0; i < elementCount; i++)
                    a[i] = elementData[i];
                if (a.Length > elementCount)
                    a[elementCount] = default(T);
                return a;
            }
        }

        // 17
        public void Add(int index, T e)
        {
            if (index < 0 || index > elementCount)
                throw new ArgumentOutOfRangeException("index");

            EnsureCapacity(elementCount + 1);

            for (int i = elementCount; i > index; i--)
                elementData[i] = elementData[i - 1];

            elementData[index] = e;
            elementCount++;
        }

        // 18
        public void AddAll(int index, T[] a)
        {
            if (a == null)
                throw new ArgumentNullException("a");
            if (index < 0 || index > elementCount)
                throw new ArgumentOutOfRangeException("index");

            int numNew = a.Length;
            if (numNew == 0)
                return;

            EnsureCapacity(elementCount + numNew);

            for (int i = elementCount - 1; i >= index; i--)
                elementData[i + numNew] = elementData[i];

            for (int i = 0; i < numNew; i++)
                elementData[index + i] = a[i];

            elementCount += numNew;
        }

        // 19
        public T Get(int index)
        {
            if (index < 0 || index >= elementCount)
                throw new ArgumentOutOfRangeException("index");

            return elementData[index];
        }

        // 20
        public int IndexOf(object o)
        {
            for (int i = 0; i < elementCount; i++)
            {
                if (object.Equals(elementData[i], o))
                    return i;
            }
            return -1;
        }

        // 21
        public int LastIndexOf(object o)
        {
            for (int i = elementCount - 1; i >= 0; i--)
            {
                if (object.Equals(elementData[i], o))
                    return i;
            }
            return -1;
        }

        // 22
        public T Remove(int index)
        {
            if (index < 0 || index >= elementCount)
                throw new ArgumentOutOfRangeException("index");

            T oldValue = elementData[index];

            for (int i = index; i < elementCount - 1; i++)
                elementData[i] = elementData[i + 1];

            elementData[elementCount - 1] = default(T);
            elementCount--;

            return oldValue;
        }

        // 23
        public void Set(int index, T e)
        {
            if (index < 0 || index >= elementCount)
                throw new ArgumentOutOfRangeException("index");

            elementData[index] = e;
        }

        // 24
        public MyVector<T> SubList(int fromIndex, int toIndex)
        {
            if (fromIndex < 0 || toIndex > elementCount || fromIndex > toIndex)
                throw new ArgumentOutOfRangeException();

            MyVector<T> result = new MyVector<T>(toIndex - fromIndex);

            for (int i = fromIndex; i < toIndex; i++)
                result.Add(elementData[i]);

            return result;
        }

        // 25
        public T FirstElement()
        {
            if (elementCount == 0)
                throw new InvalidOperationException("Vector is empty");

            return elementData[0];
        }

        // 26
        public T LastElement()
        {
            if (elementCount == 0)
                throw new InvalidOperationException("Vector is empty");

            return elementData[elementCount - 1];
        }

        // 27
        public void RemoveElementAt(int pos)
        {
            Remove(pos);
        }

        // 28
        public void RemoveRange(int begin, int end)
        {
            if (begin < 0 || end > elementCount || begin > end)
                throw new ArgumentOutOfRangeException();

            int numToRemove = end - begin;
            if (numToRemove == 0)
                return;

            for (int i = begin; i < elementCount - numToRemove; i++)
                elementData[i] = elementData[i + numToRemove];

            for (int i = elementCount - numToRemove; i < elementCount; i++)
                elementData[i] = default(T);

            elementCount -= numToRemove;
        }
    }
    class Program 
    {
        static void PrintVector<T>(MyVector<T> v, string title)
        {
            Console.Write(title + " (size = " + v.Size() + "): ");
            for (int i = 0; i < v.Size(); i++)
            {
                Console.Write(v.Get(i) + " ");
            }
            Console.WriteLine();
        }

        static void MAIN()
        {

            MyVector<int> v = new MyVector<int>();

            v.Add(10);
            v.Add(20);
            v.Add(30);
            PrintVector(v, "После Add(10,20,30)");


            int[] more = { 40, 50 };
            v.AddAll(more);
            PrintVector(v, "После AddAll({40,50})");


            v.Add(1, 99);
            PrintVector(v, "После Add(1, 99)");

  
            int x = v.Get(2);
            Console.WriteLine("Элемент на позиции 2: " + x);

            v.Set(2, 777);
            PrintVector(v, "После Set(2, 777)");


            Console.WriteLine("IndexOf(777) = " + v.IndexOf(777));
            Console.WriteLine("Contains(50) = " + v.Contains(50));


            MyVector<int> sub = v.SubList(1, 4);
            PrintVector(sub, "SubList(1,4)");

            int removed = v.Remove(3);
            Console.WriteLine("Удалили элемент: " + removed);
            PrintVector(v, "После Remove(3)");


            Console.WriteLine("Первый элемент: " + v.FirstElement());
            Console.WriteLine("Последний элемент: " + v.LastElement());

            v.RemoveRange(1, 3);
            PrintVector(v, "После RemoveRange(1,3)");

            v.Clear();
            Console.WriteLine("После удаления IsEmpty = " + v.IsEmpty());

            Console.ReadLine();
        }
    }

   
}
