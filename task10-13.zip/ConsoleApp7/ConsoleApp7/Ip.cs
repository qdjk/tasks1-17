﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    class Program3
    {
        internal class Ip
        {
            static bool IsDigitOrDot(char c)
            {
                return (c >= '0' && c <= '9') || c == '.';
            }

            // Проверка, что строка IPv4
            static bool IsValidIPv4(string s)
            {
                if (string.IsNullOrEmpty(s))
                    return false;

                string[] parts = s.Split('.');
                if (parts.Length != 4)
                    return false;

                for (int i = 0; i < 4; i++)
                {
                    string part = parts[i];

                    if (part.Length == 0)
                        return false;
                    if (part.Length > 3)
                        return false;

                    int value = 0;

                    for (int j = 0; j < part.Length; j++)
                    {
                        char c = part[j];
                        if (c < '0' || c > '9')
                            return false;

                        value = value * 10 + (c - '0');
                    }

                    if (value < 0 || value > 255)
                        return false;
                }

                return true;
            }

            static void MAIN()
            {
                MyVector<string> lines = new MyVector<string>();
                MyVector<string> ips = new MyVector<string>();


                try
                {
                    using (StreamReader sr = new StreamReader("C:\\Users\\M\\source\\repos\\ConsoleApp7\\ConsoleApp7\\input.txt"))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            lines.Add(line);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ошибка при чтении input.txt: " + ex.Message);
                    return;
                }


                for (int i = 0; i < lines.Size(); i++)
                {
                    string line = lines.Get(i);
                    int pos = 0;

                    while (pos < line.Length)
                    {
                        if (IsDigitOrDot(line[pos]))
                        {
                            int start = pos;
                            int end = pos + 1;


                            while (end < line.Length && IsDigitOrDot(line[end]))
                            {
                                end++;
                            }

                            string token = line.Substring(start, end - start);

                            if (IsValidIPv4(token))
                            {
                                ips.Add(token);
                            }

                            pos = end;
                        }
                        else
                        {
                            pos++;
                        }
                    }
                }


                try
                {
                    using (StreamWriter sw = new StreamWriter("C:\\Users\\M\\source\\repos\\ConsoleApp7\\ConsoleApp7\\output.txt"))
                    {
                        for (int i = 0; i < ips.Size(); i++)
                        {
                            sw.WriteLine(ips.Get(i));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ошибка при записи output.txt: " + ex.Message);
                }
            }
        }
    }

   
}
