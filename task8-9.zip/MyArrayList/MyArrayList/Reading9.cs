﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyArrayList
{
    class Program1
    {
      
        static bool IsValidTag(string tag)
        {
        
            if (string.IsNullOrEmpty(tag) || tag.Length < 3)
                return false;

            if (tag[0] != '<' || tag[tag.Length - 1] != '>')
                return false;

            int pos = 1;

           
            if (tag[pos] == '/')
            {
                pos++;
                if (pos >= tag.Length - 1)
                    return false;
            }

           
            if (!char.IsLetter(tag[pos]))
                return false;

            pos++;

           
            while (pos < tag.Length - 1)
            {
                char c = tag[pos];
                if (!char.IsLetterOrDigit(c))
                    return false;
                pos++;
            }

            return true;
        }

        static void TagsFromLine(string line, MyArrayList<string> tags)
        {
            int i = 0;
            while (i < line.Length)
            {
                if (line[i] == '<')
                {
                    int close = line.IndexOf('>', i + 1);
                    if (close == -1)
                        break; // нет закрывающей '>'

                    string candidate = line.Substring(i, close - i + 1);

                    if (IsValidTag(candidate))
                    {
                        tags.Add(candidate);
                    }

                    i = close + 1;
                }
                else
                {
                    i++;
                }
            }
        }

    
        static string NormalizeTag(string tag)
        {

            string inner = tag.Substring(1, tag.Length - 2); 

            if (inner.Length > 0 && inner[0] == '/')
                inner = inner.Substring(1);

            return inner.ToLowerInvariant();
        }

     
        static void RemoveDuplicateTags(MyArrayList<string> tags)
        {
            for (int i = 0; i < tags.Size; i++)
            {
                string tagI = tags.Get(i);
                string normI = NormalizeTag(tagI);

                int j = i + 1;
                while (j < tags.Size)
                {
                    string tagJ = tags.Get(j);
                    string normJ = NormalizeTag(tagJ);

                    if (normI == normJ)
                    {
                 
                        tags.RemoveFromInd(j);
                      
                    }
                    else
                    {
                        j++;
                    }
                }
            }
        }

        static void Main()
        {
            var tags = new MyArrayList<string>();

            using (StreamReader sr = new StreamReader("C:\\Users\\M\\source\\repos\\MyArrayList\\MyArrayList\\input.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    TagsFromLine(line, tags);
                }
            }

            RemoveDuplicateTags(tags);

            using (StreamWriter sw = new StreamWriter("C:\\Users\\M\\source\\repos\\MyArrayList\\MyArrayList\\output.txt"))
            {
                for (int i = 0; i < tags.Size; i++)
                {
                    sw.WriteLine(tags.Get(i));
                }
            }
        }
    }
}