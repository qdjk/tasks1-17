﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyArrayList
{
    public class MyArrayList<T> where T : IComparable<T>
    {
        private T[] _elementData;
        private int _size;
        public int Size { get { return _size; } }

        private const int _defaultCapacity = 4;
        //1
        public MyArrayList()
        {
            _elementData = new T[_defaultCapacity];
            _size = 0;
        }
        //2
        public MyArrayList(T[] other)
        {
            if (other == null) throw new InvalidOperationException("Массив пуст");
            _elementData = new T[other.Length];
            _size = other.Length;
            Array.Copy(other, 0, _elementData, 0, other.Length);
        }
        //3
        public MyArrayList(int capacity)
        {
            if (capacity < 0) throw new InvalidOperationException("Упс.. Капасити в минус ушло");
            if (capacity == 0) { _elementData = new T[_defaultCapacity]; _size = 0; }
            else
            {
                _elementData = new T[capacity];
                _size = 0;
            }
        }
        //4
        public void Add(T item)
        {

            if (_size >= _elementData.Length)
            {
                int s = Convert.ToInt32((_elementData.Length * 1.5) + 1);
                T[] arr = new T[s];
                Array.Copy(_elementData, 0, arr, 0, _size);
                _elementData = arr;
            }
            _elementData[_size] = item;
            _size++;
        }
        //5
        public void AddAll(T[] other)
        {
            if (other == null) throw new InvalidOperationException("Массив пуст");
            foreach (T item in other)
            {
                Add(item);
            }
        }
        //6
        public void Clear()
        {
            _elementData = new T[_defaultCapacity];
            _size = 0;
        }
        //7
        public bool Contains(object o)
        {
            if (o == null) throw new InvalidOperationException("пусто");
            for (int i = 0; i < _size; i++)
            {
                if (Equals(_elementData[i], o) == true) return true;
            }
            return false;
        }
        //8
        public bool ContainsAll(T[] o)
        {
            if (o == null) throw new InvalidOperationException("пусто");

            for (int i = 0; i < o.Length; i++)
            {
                bool ok = false;
                for (int j = 0; j < _size; j++)
                {
                    if (Equals(o[i], _elementData[j]) == true) ok = true;
                }
                if (ok == false) { return false; }
            }
            return true;
        }//9
        public bool IsEmpty()
        {
            if (_size == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Remove(object o)
        {

            for (int i = 0; i < _size; i++)
            {
                if (Equals(_elementData[i], o))
                {
                    for (int j = i; j < _size - 1; j++)
                    {
                        _elementData[j] = _elementData[j + 1];
                    }

                    _elementData[_size - 1] = default;
                    _size--;
                    i--;
                }

            }

        }
        //11
        public void RemoveAll(T[] arr)
        {
            if (arr == null) throw new InvalidOperationException("Массив пуст");
            for (int i = 0; i < arr.Length; i++)
            {
                Remove(arr[i]);
            }
        }
        //12
        public void RetainAll(T[] arr)
        {
            if (arr == null)
                throw new InvalidOperationException("Массив пуст");


            bool ContainsInArray(T value)
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    if (Equals(arr[i], value))
                        return true;
                }
                return false;
            }

            T[] newData = new T[_elementData.Length];
            int j = 0;

            for (int i = 0; i < _size; i++)
            {
                if (ContainsInArray(_elementData[i]))
                {
                    newData[j] = _elementData[i];
                    j++;
                }
            }

            // чистка мусора по приколу
            for (int k = j; k < _size; k++)
            {
                newData[k] = default;
            }
                

            _elementData = newData;
            _size = j;
        }
        //13
        public int size()
        {
            return _size;
        }
        //14
        public T[] ToArray()
        {
            T[] result = new T[_size];
            Array.Copy(_elementData, result, _size);
            return result;
        }
        //15
        public T[] ToArrayFromArray(T[] a)
        {

            if (a == null)
            {
                T[] result = new T[_size];
                Array.Copy(_elementData, result, _size);
                return result;
            }

            if (a.Length < _size)
            {
                T[] result = new T[_size];
                Array.Copy(_elementData, result, _size);
                return result;
            }

            Array.Copy(_elementData, a, _size);

            return a;
        }
        //16
        public void AddWithInd(int index, T element)
        {
            if (index < 0 || index > _size)
                throw new ArgumentOutOfRangeException(nameof(index));


            if (_size == _elementData.Length)
            {
                int newCapacity = _elementData.Length * 3 / 2 + 1;
                T[] newArr = new T[newCapacity];
                Array.Copy(_elementData, newArr, _size);
                _elementData = newArr;
            }


            for (int i = _size; i > index; i--)
            {
                _elementData[i] = _elementData[i - 1];
            }

            _elementData[index] = element;
            _size++;
        }
        //17
        public void AddWithIndAll(int index, T[] elements)
        {
            if (elements == null)
                throw new InvalidOperationException("пусто");

            for (int i = elements.Length - 1; i >= 0; i--)
            {
                AddWithInd(index, elements[i]);
            }
        }
        //18
        public T Get(int index)
        {
            if (index < 0 || index >= _size)
                throw new InvalidOperationException("пусто");
            return _elementData[index];
        }
        //19
        public int IndexOf(object o)
        {
            for (int i = 0; i < _size; i++)
            {
                if (Equals(o, _elementData[i]))
                {
                    return i;
                }
            }
            return -1;
        }
        //20
        public int LastIndexOf(object o)
        {
            for (int i = _size - 1; i >= 0; i--)
            {
                if (Equals(_elementData[i], o))
                    return i;
            }

            return -1;
        }
        //21
        public T RemoveFromInd(int index)
        {
            if (index < 0 || index >= _size)
                throw new InvalidOperationException("пусто");


            T removed = _elementData[index];

            for (int i = index; i < _size - 1; i++)
            {
                _elementData[i] = _elementData[i + 1];
            }

            _elementData[_size - 1] = default;
            _size--;

            return removed;
        }
        //22
        public void Set(int index, T element)
        {
            if (index < 0 || index >= _size)
                throw new InvalidOperationException("пусто");

            _elementData[index] = element;
        }
        //23
        public MyArrayList<T> SubList(int fromIndex, int toIndex)
        {
            if (fromIndex < 0 || toIndex > _size || fromIndex > toIndex)
                throw new InvalidOperationException("пусто");

            int length = toIndex - fromIndex;
            T[] arr = new T[length];

            if (length > 0)
                Array.Copy(_elementData, fromIndex, arr, 0, length);

            return new MyArrayList<T>(arr);
        }


    }



}
