﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
/*
 4) Метод add(T e) для добавления элемента в конец динамического массива.
Если размер динамического массива больше размера внутреннего
массива, необходимо создать новый массив размером в 1,5 раза больше
исходного, плюс один элемент, скопировать все элементы из старого
массива в новый и сохранить новый массив во внутренней переменной
объекта MyArrayList.
 */
namespace MyArrayList
{
   


    internal class Program
    {
        static void Main2(string[] args)
        {
            MyArrayList<int> list = new MyArrayList<int>();

            list.Add(10);
            list.Add(20);
            list.Add(30);

            Console.WriteLine("После Add: " + string.Join(", ", list.ToArray()));

            list.AddWithInd(1, 999);
            Console.WriteLine("После AddWithInd(1,999): " + string.Join(", ", list.ToArray()));

            list.AddAll(new int[] { 40, 50 });
            Console.WriteLine("После AddAll: " + string.Join(", ", list.ToArray()));

            Console.WriteLine("Get(2): " + list.Get(2));
            Console.WriteLine("IndexOf(999): " + list.IndexOf(999));

            list.Remove(999);
            Console.WriteLine("После Remove(999): " + string.Join(", ", list.ToArray()));

            int removed = list.RemoveFromInd(1);
            Console.WriteLine("Удалили: " + removed);
            Console.WriteLine("После RemoveFromInd(1): " + string.Join(", ", list.ToArray()));

            MyArrayList<int> sub = list.SubList(0, 2);
            Console.WriteLine("SubList(0,2): " + string.Join(", ", sub.ToArray()));

            list.Clear();
            Console.WriteLine("IsEmpty: " + list.IsEmpty());

        }
    }
}
